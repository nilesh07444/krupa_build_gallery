﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KrupaBuildGallery.Areas.Client.Controllers
{
    public class HappyCustomerController : Controller
    {
        // GET: Client/HappyCustomer
        public ActionResult Index()
        {
            return View();
        }
    }
}