﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KrupaBuildGallery
{
    public class OtpVM
    {
        public string Otp { get; set; }

        public string MobileNo { get; set; }

        public string UserType { get; set; }

        public string OrderId { get; set; }

        public string PriceString { get; set; }
    }
}