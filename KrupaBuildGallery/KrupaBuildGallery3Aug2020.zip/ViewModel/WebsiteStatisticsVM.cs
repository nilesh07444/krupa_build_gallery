﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KrupaBuildGallery
{
    public class WebsiteStatisticsVM
    {
        public int TotalCustomers { get; set; }
        public int TotalDistributers { get; set; }
        public int TotalHappyCustomers { get; set; }
        public int TotalSiteVisitors { get; set; }
        public int TotalItems { get; set; }
    }
}