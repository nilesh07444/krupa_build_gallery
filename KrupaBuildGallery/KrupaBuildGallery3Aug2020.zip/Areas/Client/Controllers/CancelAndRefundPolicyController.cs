﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KrupaBuildGallery.Areas.Client.Controllers
{
    public class CancelAndRefundPolicyController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}